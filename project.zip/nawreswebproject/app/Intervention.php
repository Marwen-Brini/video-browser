<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Intervention extends Model
{
    public function clients(){
    	return $this->belongsToMany('App\Client');
    }

    public function cars(){
    	return $this->belongsToMany('App\Car');
    }

    public function installers(){
    	return $this->belongsToMany('App\User');
    }

    public function cases(){
    	return $this->belongsToMany('App\Cas');
    }
}
