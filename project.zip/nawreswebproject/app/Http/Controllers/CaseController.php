<?php

namespace App\Http\Controllers;

use App\Car;
use App\Cas;
use Illuminate\Http\Request;
class CaseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('cases.index')->withCases(Cas::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('cases.create')->withCars(Car::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $case = new Cas();
        $case->entity = $request->entity;
        $case->type = $request->type;
        $case->name = $request->name;
        $case->save();
        $case->cars()->sync($request->car_id);
        return redirect()->route('cases.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('cases.edit')->withCase(Cas::findOrFail($id))->withCars(Car::all());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $case = Cas::findOrFail($id);
        $case->entity = $request->entity;
        $case->type = $request->type;
        $case->name = $request->name;
        $case->save();
        $case->cars()->sync($request->car_id);
        return redirect()->route('cases.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $c = Cas::FindOrFail($id);
        if($c->delete()){
            return redirect()->route('cases.index');
        }
    }
}
