<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;
use App\Car;
use App\User;
use App\Cas;
use App\Intervention;
class InterventionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('interventions.index')->withInters(Intervention::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $clients = Client::all();
        $cars = Car::all();
        $installers = User::all();
        $cases = Cas::all();
        return view('interventions.create')->withClients($clients)->withCars($cars)->withInstallers($installers)->withCases($cases);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inter = new Intervention();
        $inter->description = $request->description;
        $inter->state = $request->state;
        $inter->save();
        $inter->clients()->sync($request->client_id);
        $inter->cars()->sync($request->car_id);
        $inter->installers()->sync($request->user_id);
        $inter->cases()->sync($request->cas_id);
        
        return redirect()->route('inter.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $clients = Client::all();
        $cars = Car::all();
        $installers = User::all();
        $cases = Cas::all();
        return view('interventions.edit')->withInter(Intervention::findOrFail($id))->withClients($clients)->withCars($cars)->withInstallers($installers)->withCases($cases);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $inter = Intervention::findOrFail($id);
        $inter->description = $request->description;
        $inter->state = $request->state;
        $inter->save();
        $inter->clients()->sync($request->client_id);
        $inter->cars()->sync($request->car_id);
        $inter->installers()->sync($request->user_id);
        $inter->cases()->sync($request->cas_id);
        
        return redirect()->route('inter.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $inter = Intervention::findOrFail($id);
        if($inter->delete()){
            return redirect()->route('inter.index');
        }
    }
}
