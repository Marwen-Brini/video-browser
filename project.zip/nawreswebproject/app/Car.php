<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    public function client(){
        return $this->belongsTo('App\Client');
    }

    public function cases(){
    	return $this->belongsToMany('App\Cas');
    }

    public function interventions(){
    	return $this->belongsToMany('App\Intervention');
    }
}
