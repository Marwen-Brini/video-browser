<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cas extends Model
{
    public function cars(){
    	return $this->belongsToMany('App\Car');
    }

    public function interventions(){
    	return $this->belongsToMany('App\Intervention');
    }
}
