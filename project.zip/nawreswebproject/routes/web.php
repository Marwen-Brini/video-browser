<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();
//users routes
Route::get('/installers','UserController@index')->name('user.index');
Route::get('/installer/{id}','UserController@show')->name('user.show');
Route::post('/installer','UserController@store')->name('user.store');
Route::get('/installer/{id}/delete','UserController@destroy')->name('user.delete');
Route::get('/installer/{id}/edit','UserController@edit')->name('user.edit');
Route::get('newinstaller','UserController@create')->name('user.create');
Route::post('/installer/{id}/update','UserController@update')->name('user.update');
//client routes
Route::prefix('api')->group(function(){
	Route::get('/clients','ClientController@index');
	Route::get('/client/{id}','ClientController@show');
	Route::post('/client','ClientController@store');

});

Route::get('/clients','ClientsController@index')->name('clients.index');
Route::get('/client/{id}/delete','ClientsController@destroy')->name('client.delete');
Route::get('/newClient','ClientsController@create')->name('client.create');
Route::post('/client','ClientsController@store')->name('client.store');
Route::get('/client/{id}/get','ClientsController@edit')->name('client.edit');
Route::post('/client/{id}/update','ClientsController@update')->name('client.update');

//cars routes
Route::get('/cars','CarsController@index')->name('cars.index');
Route::get('/newcar','CarsController@create')->name('car.create');
Route::post('/car','CarsController@store')->name('car.store');
Route::get('/car/{id}/edit','CarsController@edit')->name('car.edit');
Route::post('/car/{id}/update','CarsController@update')->name('car.update');
Route::get('/car/{id}/delete','CarsController@destroy')->name('car.delete');

//Cases routes
Route::get('/cases','CaseController@index')->name('cases.index');
Route::get('/newcase','CaseController@create')->name('case.create');
Route::get('/case/{id}/edit','CaseController@edit')->name('case.edit');
Route::post('/newcase','CaseController@store')->name('case.store');
Route::post('/case/{id}/update','CaseController@update')->name('case.update');
Route::get('/case/{id}/delete','CaseController@destroy')->name('case.delete');


Route::get('/home', 'HomeController@index')->name('home');


//interventions routes
Route::get('/newintervention','InterventionController@create')->name('inter.create');
Route::get('/interventions','InterventionController@index')->name('inter.index');
Route::post('/invention','InterventionController@store')->name('inter.store');
Route::get('/intervention/{id}/edit','InterventionController@edit')->name('inter.edit');
Route::post('/intervention/{id}/update','InterventionController@update')->name('inter.update');
Route::get('/intervention/{id}/delete','InterventionController@destroy')->name('inter.delete');


