@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			<div class="col-md-6 offset-3">
				<h3 class="text-center">Create New Client</h3>
				<form action="{{route('client.store')}}" method="post" enctype="multipart/form-data">
					@csrf
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="name" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>Phone</label>
						<input type="number" name="phone" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>Address</label>
						<input type="text" name="address" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>Image</label>
						<input type="file" name="image" id="" class="form-control">
					</div>
					<div class="text-center">
						
					<button class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
@endsection