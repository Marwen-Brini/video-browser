@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			
			<div class="col">
				<div class="card shadow mb-4">
		            <div class="card-header py-3">
		              <h6 class="m-0 font-weight-bold text-primary">Clients</h6>
		              <div class="text-right">
		              	
		              <a href="{{route('client.create')}}" class="btn btn-primary" title="add new client"><i class="fas fa-user mr-1"></i>+</a>
		              </div>
		            </div>
		            <div class="card-body">
		              <div class="table-responsive">
		                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		                  <thead>
		                    <tr>
		                      
		                      <th>Name</th>
		                      <th>Email</th>
		                      <th>Telephone</th>
		                      <th>Address</th>
		                      <th>picture</th>
		                      <th>Action</th>
		                    </tr>
		                  </thead>
		                  <tbody>
		                  	@foreach($clients as $client)
		                  		<tr>
		                  			<td>{{$client->name}}</td>
		                  			<td>{{$client->email}}</td>
		                  			<td>{{$client->phone}}</td>
		                  			<td>{{$client->address}}</td>
		                  			<td><img src="{{str_replace( '/var/www/strada.shweb.tn/public','',$client->image)}}" width="36" height="36"></td>
		                  			<td><a href="{{route('client.edit',['id'=>$client->id])}}" class="btn btn-success">Edit</a> <a  onclick="return confirm('Are you sure you want to delete this?')"  href="{{route('client.delete',['id'=>$client->id])}}"  class="btn btn-danger">delete</a></td>
		                  		</tr>
		                  	@endforeach
		                  </tbody>
		                </table>
		               </div>
		             </div>
		        </div>
			</div>
		</div>
	</div>						
@endsection