@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			
			<div class="col">
				<div class="card shadow mb-4">
		            <div class="card-header py-3">
		              <h6 class="m-0 font-weight-bold text-primary">Interventions</h6>
		              <div class="text-right">
		              	
		              <a href="{{route('inter.create')}}" class="btn btn-primary" title="add new Intervention"><i class="fas fa-hammer mr-1"></i><span style="font-size: 18px;">+</span></a>
		              </div>
		            </div>
		            <div class="card-body">
		              <div class="table-responsive">
		                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		                  <thead>
		                    <tr>
		                      
		                      <th>Description</th>
		                      <th>state</th>
		                      <th>Client name</th>
		                      <th>Car plate</th>
		                      <th>case entity </th>
		                      <th>installer name</th>
		                      <th>Action</th>
		                    </tr>
		                  </thead>
		                  <tbody>
		                  	@foreach($inters as $i)
		                  		<tr>
		                  			<td>{{$i->description}}</td>
		                  			<td>{{$i->state}}</td>
		                  				@foreach($i->clients as $c)
		                  					<td>{{$c->name}}</td>
		                  				@endforeach
		                  				@foreach($i->cars as $ca)
		                  					<td>{{$ca->plate_number}}</td>
		                  				@endforeach
		                  				@foreach($i->cases as $cas)
		                  					<td>{{$cas->entity}}</td>
		                  				@endforeach
		                  				@foreach($i->installers as $case)
		                  					<td>{{$case->name}}</td>
		                  				@endforeach
		                  			<td><a href="{{route('inter.edit',['id'=>$i->id])}}" class="btn btn-success">Edit</a> <a  onclick="return confirm('Are you sure you want to delete this?')"  href="{{route('inter.delete',['id'=>$i->id])}}"  class="btn btn-danger">delete</a></td>
		                  			
		                  		</tr>
		                  	@endforeach
		                  </tbody>
		                </table>
		               </div>
		             </div>
		        </div>
			</div>
		</div>
	</div>						
@endsection