@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			<div class="col-md-6 offset-3">
				<h3 class="text-center">Create New Intervention</h3>
				<form action="{{route('inter.store')}}" method="post" enctype="multipart/form-data">
					@csrf
					<div class="form-group">
						<label>description</label>
						<textarea name="description" cols="30" rows="3" class="form-control"></textarea>
					</div>
					<div class="form-group">
						<label>state</label>
						<select name="state" class="form-control">
							<option value="to_plan">To Plan</option>
							<option value="planned">Planned</option>
							<option value="pending">Pending</option>
						</select>
					</div>
					<div class="form-group">
						<label>Client</label>
						<select name="client_id" id="" class="form-control">
							@foreach($clients as $client)
									<option value="{{$client->id}}">{{$client->name}}</option>
							@endforeach

						</select>
					</div>
					<div class="form-group">
						<label>Car</label>
						<select name="car_id" id="" class="form-control">
							@foreach($cars as $car)
									<option value="{{$car->id}}">{{$car->plate_number}}</option>
							@endforeach

						</select>
					</div>
					 <div class="form-group">
						<label>Installer</label>
						<select class="form-control" name="user_id">
							@foreach($installers as $installer)
							<option value="{{$installer->id}}">{{$installer->name}}</option>
							@endforeach
							
						</select>
					</div>
					<div class="form-group">
						<label>Cases</label>
						<select class="form-control" name="cas_id">
							@foreach($cases as $c)
							<option value="{{$c->id}}">{{$c->entity}}</option>
							@endforeach
							
						</select>
					</div>
					 
					<div class="text-center">
						
					<button class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
@endsection