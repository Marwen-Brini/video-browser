@component('mail::message')
# Welcome

Welcome onboard your password is <strong>{{$data}}</strong>


Thanks,<br>
{{ config('app.name') }}
@endcomponent
