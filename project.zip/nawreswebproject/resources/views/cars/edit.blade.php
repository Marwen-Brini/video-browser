@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h2 class="text-center">edit car</h2>
			<form action="{{route('car.update',['id'=>$car->id])}}" method="post">
				@csrf
				<div class="form-group">
					<label>Type</label>
					<input type="text" name="type" class="form-control" value="{{$car->type}}">
				</div>
				<div class="form-group">
					<label>marque</label>
					<input type="text" name="marque" class="form-control" value="{{$car->marque}}">
				</div>
				<div class="form-group">
					<label >Plate Number</label>
					<input type="text" name="plate_number" id="" class="form-control" value="{{$car->plate_number}}">
				</div>
				<div class="form-group">
					<select name="user_id" class="form-control">
						@foreach($clients as $c)
                           <option value="{{$c->id}}" 
                           	@if($car->client->id == $c->id)
                           		selected="selected" 

                           	@endif
                           	>{{$c->name}}</option>
						@endforeach
					</select>
				</div>
				<div class="text-center">
					<input type="submit" value="update car" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>
</div>
@endsection