@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			
			<div class="col">
				<div class="card shadow mb-4">
		            <div class="card-header py-3">
		              <h6 class="m-0 font-weight-bold text-primary">Installers</h6>
		              <div class="text-right">
		              	
		              <a href="{{route('user.create')}}" class="btn btn-primary" title="add new installer"><i class="fas fa-user mr-1"></i>+</a>
		              </div>
		            </div>
		            <div class="card-body">
		              <div class="table-responsive">
		                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
		                  <thead>
		                    <tr>
		                      
		                      <th>Name</th>
		                      <th>Email</th>
		                      <th>Speciality</th>
		                      <th>picture</th>
		                      <th>Action</th>
		                    </tr>
		                  </thead>
		                  <tbody>
		                  	@foreach($users as $user)
		                  		<tr>
		                  			<td>{{$user->name}}</td>
		                  			<td>{{$user->email}}</td>
		                  			<td>{{$user->speciality}}</td>
		                  			<td><img src="{{str_replace( '/var/www/strada.shweb.tn/public','',$user->photo)}}" width="36" height="36"></td>
		                  			<td><a href="{{route('user.edit',['id'=>$user->id])}}" class="btn btn-success">Edit</a> <a  onclick="return confirm('Are you sure you want to delete this?')"  href="{{route('user.delete',['id'=>$user->id])}}"  class="btn btn-danger">delete</a></td>
		                  		</tr>
		                  	@endforeach
		                  </tbody>
		                </table>
		               </div>
		             </div>
		        </div>
			</div>
		</div>
	</div>						
@endsection