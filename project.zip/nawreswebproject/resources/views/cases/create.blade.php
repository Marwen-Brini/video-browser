@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			<div class="col-md-6 offset-3">
				<h3 class="text-center">Create New Case</h3>
				<form action="{{route('case.store')}}" method="post" enctype="multipart/form-data">
					@csrf
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="name" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>entity</label>
						<input type="text" name="entity" id="" class="form-control">
					</div>
					<div class="form-group">
						<label>Type</label>
						<select name="type" id="" class="form-control">
							<option value="type_a">Type A</option>
							<option value="type_b">Type B</option>
						</select>
					</div>
					<div class="form-group">
						<label>Plate number</label>
						<select class="form-control" name="car_id">
							@foreach($cars as $c)
								<option value="{{$c->id}}">{{$c->plate_number}}</option>
							@endforeach
						</select>
					</div>
					
					<div class="text-center">
						
					<button class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>
@endsection